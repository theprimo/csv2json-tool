package com.pru.prop;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

public class CsvToJson {

	public static void main(String[] args) {

		Properties prop = new Properties();
		FileReader reader = null;

		try {
			reader = new FileReader("local.properties");
		} catch (FileNotFoundException e2) {
			e2.printStackTrace();
		}
		try {
			prop.load(reader);

		} catch (IOException e1) {
			e1.printStackTrace();
		}
		long start = System.currentTimeMillis();
		try {
			File folder = new File(prop.getProperty("csv_folder_path"));
			File[] files = folder.listFiles();
			String outputFilePath = prop.getProperty("output_file");
			String fileName = null;
			File newTextFile = null;
			FileOutputStream fout = null;
			String filePath;
			StringBuilder stringBuffer = null;
			List<String> fieldNames = null;
			int j = 0,count=0,len=0;
			Map<String, String> obj = null;
			String fieldValueStr = "";
			
			for (int i = 0; i < files.length; i++) {
				System.out.println(files[i].getName());
				fileName = (files[i].getName().toString()).split("\\.")[0];
				outputFilePath = prop.getProperty("output_file") + "\\" + fileName + ".json";
				newTextFile = new File(outputFilePath);
				System.out.println("file name :::"+fileName);
				fout = new FileOutputStream(newTextFile);
				filePath = prop.getProperty("csv_folder_path") + "\\" + files[i].getName();
				try (InputStream in = new FileInputStream(filePath);) {
					CSV csv = new CSV(true, ',', in);
					count = 101;

					if (csv.hasNext())
						fieldNames = new ArrayList<>(csv.next());

					while (csv.hasNext()) {
						stringBuffer = new StringBuilder();
						List<String> x = csv.next();
						obj = new HashMap<>();
						try {
							for (j=0;j<fieldNames.size();j++) {

								boolean splCharFlag=false;								
								if(j<x.size()) {    
									fieldValueStr = x.get(j);
									//remove leading & trailing strings "\","\."
									len=fieldValueStr.length();
									if((len>2)&&(fieldValueStr.startsWith("\\."))) {
										fieldValueStr=fieldValueStr.substring(2);
										len=fieldValueStr.length();
									}
									if((len>2)&&(fieldValueStr.endsWith("\\."))) {
										fieldValueStr=fieldValueStr.substring(0, len-2);
										len=fieldValueStr.length();
									}									
									if((len>1)&&(fieldValueStr.startsWith("\\"))) {
										fieldValueStr=fieldValueStr.substring(1);
										len=fieldValueStr.length();
									}
									if((len>1)&&(fieldValueStr.endsWith("\\"))) {
										fieldValueStr=fieldValueStr.substring(0, len-1);
										len=fieldValueStr.length();
									}

									//check for special characters
									for(int k=0;(!splCharFlag)&&(k<len);k++){
										int ascval=fieldValueStr.charAt(k);
										if(ascval<32 || ascval>126){
											char ch=(char)ascval;
											splCharFlag=true;
											System.out.println("special character found:"+ch);
										}									   
									} 
								}
								if(j<x.size() && !splCharFlag) { 
									obj.put("\"" + fieldNames.get(j).toLowerCase() + "\"", "\"" + fieldValueStr  + "\"");
								} else {
									obj.put("\"" + fieldNames.get(j).toLowerCase() + "\"", "\"" + "" + "\"");
								}									
							}
						}catch(Exception e) {
							e.printStackTrace();
						}
						obj.put("\"SRC_CDC_OPERATION\"", "\"INSERT\"");
						obj.put("\"SRC_TABLE_NAME\"", "\"" + fileName + "\"");
						obj.put("\"SRC_SYSTEM\"", "\"LifeAsia\"");
						count++;
						obj.put("\"rrn\"",String.valueOf(count++));
						stringBuffer.append("{\"data\":" + (obj.toString() + "}\n").replace("=", ":"));
						byte[] s = stringBuffer.toString().getBytes();

						fout.write(s);						
					}
					fout.close();
				} catch(IndexOutOfBoundsException ie) {
					for(int x=j;x<fieldNames.size();x++) {
						obj.put("\"" + fieldNames.get(j).toLowerCase() + "\"", "\""  + "\"");
					}
					obj.put("\"SRC_CDC_OPERATION\"", "\"INSERT\"");
					obj.put("\"SRC_TABLE_NAME\"", "\"" + fileName + "\"");
					obj.put("\"SRC_SYSTEM\"", "\"LifeAsia\"");
					//count++;
					obj.put("\"rrn\"",String.valueOf(count++));
					stringBuffer.append("{\"data\":" + (obj.toString() + "}\n").replace("=", ":"));
					byte[] s = stringBuffer.toString().getBytes();

					fout.write(s);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("time taken: " + (System.currentTimeMillis() - start) +"ms");
	}

	/*private static long getUsedMemory() {
		System.gc();
		return Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
	}*/

}